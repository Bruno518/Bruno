package model.entity;

public class Korisnik {
    private final String naziv;
    private final String hashPass;
    private final String role;

    public Korisnik(String naziv, String hashPass, String role) {
        this.naziv = naziv;
        this.hashPass = hashPass;
        this.role = role;
    }

    public String getnaziv() {
        return naziv;
    }

    public String gethashPass() {
        return hashPass;
    }

    public String getRole() {
        return role;
    }
}
