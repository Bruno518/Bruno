﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pardus.Models;
namespace Pardus.Controllers
{
    [Route("Controller/Login")]
    public class LoginController : Controller
    {
        private readonly PardusDbContext _context;

        public LoginController(PardusDbContext context)
        {
            _context = context;
        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                
                var user = await _context.Users.FirstOrDefaultAsync(u => u.username == model.Username && u.password == model.Password);

                if (user != null)
                {
                    return RedirectToAction("Index", "Home"); 
                }
                else
                {
                    ModelState.AddModelError("", "Invalid username or password.");
                }
            }

            return View(model);
        }
    }
}
