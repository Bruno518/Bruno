package threads;

import model.entity.Utakmica;
import model.interfaces.ObjectWrite;

import java.io.IOException;
import java.sql.*;

import static com.example.java_project.Database.closeConnection;
import static com.example.java_project.Database.makeConnection;

public class AddGameThread implements Runnable, ObjectWrite
{
    private final Utakmica s;
    public AddGameThread(Utakmica s)
    {
        this.s=s;
    }

    @Override
    public void run()
    {
        Connection connection = makeConnection();
        if(s.getVrstaUtakmice().equals("n"))
        {
            try (PreparedStatement preparedStatement = connection.prepareStatement
                    ("INSERT INTO java_projekt.utakmica (vrsta_utakmice, id_natjecanja, id_kluba1, id_kluba2, dat_utakmice, id_stadion) values (?,?,?,?,?,?);",
                            Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setString(1, s.getVrstaUtakmice());
                preparedStatement.setLong(2, s.idNatjecanja());
                preparedStatement.setLong(3, s.getSportskiKlub1().getId());
                preparedStatement.setLong(4, s.getSportskiKlub2().getId());
                preparedStatement.setDate(5, Date.valueOf(s.getDatumUtakmice()));
                preparedStatement.setLong(6, s.getIdStadiona());
                preparedStatement.executeUpdate();
                writeObject(s);
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                throw new RuntimeException(e);
            } finally {
                closeConnection(connection);
            }
        }
        else
        {
            try (PreparedStatement preparedStatement = connection.prepareStatement
                    ("INSERT INTO java_projekt.utakmica (vrsta_utakmice, id_kluba1, id_kluba2, dat_utakmice, id_stadion) values (?,?,?,?,?);",
                            Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setString(1, s.getVrstaUtakmice());
                preparedStatement.setLong(2, s.getSportskiKlub1().getId());
                preparedStatement.setLong(3, s.getSportskiKlub2().getId());
                preparedStatement.setDate(4, Date.valueOf(s.getDatumUtakmice()));
                preparedStatement.setLong(5, s.getIdStadiona());
                preparedStatement.executeUpdate();
                writeObject(s);
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                throw new RuntimeException(e);
            } finally {
                closeConnection(connection);
            }
        }
    }

}
