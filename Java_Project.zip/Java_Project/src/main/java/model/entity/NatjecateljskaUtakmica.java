package model.entity;

import java.io.Serializable;
import java.time.LocalDate;

public class NatjecateljskaUtakmica extends Utakmica implements Serializable {
    private Long idNatjecanja;
    public NatjecateljskaUtakmica(Long id, SportskiKlub sportskiKlub1, SportskiKlub sportskiKlub2, LocalDate datumUtakmice, Long idNatjecanja, Long idStadion) {
        super(id, sportskiKlub1, sportskiKlub2, datumUtakmice, idStadion);
        this.idNatjecanja=idNatjecanja;
    }
    @Override
    public Long idNatjecanja() {
        return idNatjecanja;
    }

    @Override
    public String getVrstaUtakmice() {
        return "n";
    }
}
