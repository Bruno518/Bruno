package com.example.java_project;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.entity.Igrac;
import model.entity.Natjecanje;
import model.entity.SportskiKlub;
import model.enumeration.Aktivnost;
import model.interfaces.SetScreen;
import threads.LoadClubThread;
import threads.LoadPlayerThread;

import java.time.LocalDate;

public class ShowPlayersController implements SetScreen {
    @FXML
    public TableView<Igrac> playerTable;
    @FXML
    public TableColumn<Igrac,Long> idCol;
    @FXML
    public TableColumn<Igrac,String> nameCol;
    @FXML
    public TableColumn<Igrac,String> lastNameCol;
    @FXML
    public TableColumn<Igrac,Long> numberCol;
    @FXML
    public TableColumn<Igrac,Long> playedCol;
    @FXML
    public TableColumn<Igrac,Long> goalCol;
    @FXML
    public TableColumn<Igrac,String> activityCol;
    @FXML
    public TableColumn<Igrac,Long> clubCol;

    public void initialize()
    {
        LoadPlayerThread l=new LoadPlayerThread();
        l.run();

        ObservableList<Igrac> playerList= FXCollections.observableArrayList(l.getPlayers().values());

        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameCol.setCellValueFactory(new PropertyValueFactory<>("ime"));
        lastNameCol.setCellValueFactory(new PropertyValueFactory<>("prezime"));
        numberCol.setCellValueFactory(new PropertyValueFactory<>("brojIgraca"));
        playedCol.setCellValueFactory(new PropertyValueFactory<>("brojOdigranihUtakmica"));
        goalCol.setCellValueFactory(new PropertyValueFactory<>("brojGolova"));

        activityCol.setCellValueFactory(cellData -> {
            Igrac player = cellData.getValue();
            return new SimpleStringProperty(player.getStatusIgraca().getStatus());
        });

        playerTable.setItems(playerList);
    }

    public void back()
    {goBack();}
}
