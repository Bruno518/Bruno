package model.enumeration;

public enum Aktivnost {
    AKTIVAN("Aktivan"),
    NE_AKTIVAN("Ne_aktivan");

    private String status;

    Aktivnost(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}
