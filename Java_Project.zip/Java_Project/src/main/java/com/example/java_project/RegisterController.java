package com.example.java_project;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import model.Exceptions.PasswordMismatchException;
import model.Exceptions.UserExistsException;
import model.encryption.PassEncryption;
import model.entity.Korisnik;
import model.entity.UserLoader;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

import model.interfaces.SetScreen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RegisterController implements SetScreen {
    private static final Logger logger= LoggerFactory.getLogger(RegisterController.class);

    @FXML
    private TextField userText;
    @FXML
    private TextField passText;
    @FXML
    private TextField confText;
    private Map<String, Korisnik> korisnici = new HashMap<>();
    @FXML
    public void initialize() {
        UserLoader userLoader = new UserLoader();
        korisnici = userLoader.loadUsers("src/main/java/dat/users.txt");
    }
    public void registerButton() {
        if(userText.getText().isEmpty() || passText.getText().isEmpty() || confText.getText().isEmpty())
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Input error!");
            alert.setHeaderText(null);
            alert.setContentText("Please input your username, password and confirm your password!");
            logger.error("Wrong user information!");
            alert.showAndWait();
        }
        else {
            try(BufferedWriter write = new BufferedWriter(new FileWriter("src/main/java/dat/users.txt", true))) {
                String username = userText.getText();
                String password = passText.getText();
                String confPass = confText.getText();

                checkPasswords(password, confPass);
                checkUser(username);

                final var crypt = new PassEncryption();
                final var encryptedPass = crypt.encrypt(password);
                write.write(username + ":" + encryptedPass + ":u"+"\n");

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Registration Successful!");
                alert.setHeaderText(null);
                alert.setContentText("User registered successfully!");
                alert.showAndWait();

            } catch (PasswordMismatchException e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Password Mismatch!");
                alert.setHeaderText(null);
                alert.setContentText(e.getMessage());
                logger.error("Password Mismatch!");
                alert.showAndWait();
            } catch (UserExistsException e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("User already exists!");
                alert.setHeaderText(null);
                alert.setContentText(e.getMessage());
                logger.error("User already exists!");
                alert.showAndWait();
            }  catch (NoSuchPaddingException | InvalidKeyException | BadPaddingException | InvalidAlgorithmParameterException | IllegalBlockSizeException | NoSuchAlgorithmException e) {
                logger.error("Password crypt error");
                throw new RuntimeException(e);
            }  catch (IOException e) {
                logger.error("Unkown error! "+e.getMessage());
            }
            userText.clear();
            passText.clear();
            confText.clear();
        }
    }

    public void back()
    {
        goBack();
    }

    public void checkUser(String username) throws UserExistsException{
        if(korisnici.get(username)!=null)
        {
            throw new UserExistsException("User already exists!");
        }
    }
    public void checkPasswords(String password, String confPass) throws PasswordMismatchException {
        if (!password.equals(confPass)) {
            throw new PasswordMismatchException("Passwords do not match. Please try again.");
        }
}
}