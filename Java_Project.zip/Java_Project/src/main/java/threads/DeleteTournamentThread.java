package threads;

import com.example.java_project.Database;
import javafx.scene.control.Alert;
import model.entity.Natjecanje;
import model.interfaces.ObjectWrite;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import static com.example.java_project.Database.closeConnection;

public class DeleteTournamentThread implements Runnable, ObjectWrite {
    private final String competitionName;

    public DeleteTournamentThread(String competitionName) {
        this.competitionName = competitionName;
    }

    @Override
    public void run() {
        LoadTournamentThread l=new LoadTournamentThread();
        l.run();
        Map<Long, Natjecanje> tours=l.getTournaments();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        PreparedStatement preparedStatement1 = null;
        Long tourID = 0L;
        for(Natjecanje n:tours.values())
        {
            if(n.getImeNatjecanja().equals(competitionName))
            {
                tourID=n.getId_natjecanja();

            }
        }

        try {
            connection = Database.makeConnection();

            String deleteQuery1 = "DELETE FROM utakmica WHERE id_natjecanja = ?";
            preparedStatement1 = connection.prepareStatement(deleteQuery1);
            preparedStatement1.setLong(1, tourID);
            preparedStatement1.executeUpdate();

            String deleteQuery = "DELETE FROM natjecanje WHERE ime_nat = ?";
            preparedStatement = connection.prepareStatement(deleteQuery);
            preparedStatement.setString(1, competitionName);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Please input the correct information!");
                alert.show();

            } else {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Success!");
                alert.setContentText("Successful input!");
                alert.setHeaderText(null);
                alert.show();
            }
            writeObject(tours.get(tourID));
        } catch (SQLException | IOException e) {
            throw new RuntimeException(e);
        } finally {
            closeConnection(connection);
        }
        }
    }

