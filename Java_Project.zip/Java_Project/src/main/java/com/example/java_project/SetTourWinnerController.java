package com.example.java_project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import model.entity.Natjecanje;
import model.entity.SportskiKlub;
import model.interfaces.SetScreen;
import threads.LoadTournamentThread;
import threads.SetTourWinnerThread;
import threads.SetWinnerThread;

import java.io.IOException;
import java.util.Map;

public class SetTourWinnerController implements SetScreen {
    @FXML
    public ComboBox<String> tourName;
    @FXML
    public TextField tourResult;

    public void initialize()
    {
        LoadTournamentThread l=new LoadTournamentThread();
        l.run();
        Map<Long, Natjecanje> tours=l.getTournaments();

        ObservableList<String> list = FXCollections.observableArrayList();

        for (Natjecanje n : tours.values()) {
            list.add(n.getImeNatjecanja());
        }
        tourName.setItems(list);
    }
    public void setTourWinner()
    {
        if(tourName.getValue()==null||tourResult.getText().isEmpty())
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please input the correct information!");
            alert.show();

        }
        else{
            SetTourWinnerThread s = new SetTourWinnerThread(tourResult.getText(), tourName.getValue());
            s.run();

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Success!");
            alert.setContentText("Successful input!");
            alert.setHeaderText(null);
            alert.show();
        }
    }
    public void back()
    {
        goBack();
    }
}
