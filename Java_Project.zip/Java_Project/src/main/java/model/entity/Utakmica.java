package model.entity;

import java.time.LocalDate;

public abstract class Utakmica {
    private final Long idUtakmice;
    private SportskiKlub sportskiKlub1;
    private SportskiKlub sportskiKlub2;
    private LocalDate datumUtakmice;
    private String rezultatUtakmice;
    private final Long idStadion;

    public Utakmica(Long id, SportskiKlub sportskiKlub1, SportskiKlub sportskiKlub2, LocalDate datumUtakmice, Long idStadion){
        idUtakmice=id;
        this.sportskiKlub1 = sportskiKlub1;
        this.sportskiKlub2 = sportskiKlub2;
        this.datumUtakmice = datumUtakmice;
        this.idStadion = idStadion;
    }
    public abstract String getVrstaUtakmice();
    public Long getIdUtakmice() {
        return idUtakmice;
    }
    public Long getIdStadiona() {
        return idStadion;
    }
    public String getRezultatUtakmice() {
        return rezultatUtakmice;
    }
    public void setRezultatUtakmice(String rezultatUtakmice) {
        this.rezultatUtakmice = rezultatUtakmice;
    }
    public SportskiKlub getSportskiKlub1() {
        return sportskiKlub1;
    }
    public void setSportskiKlub1(SportskiKlub sportskiKlub1) {
        this.sportskiKlub1 = sportskiKlub1;
    }
    public SportskiKlub getSportskiKlub2() {
        return sportskiKlub2;
    }
    public void setSportskiKlub2(SportskiKlub sportskiKlub2) {
        this.sportskiKlub2 = sportskiKlub2;
    }
    public LocalDate getDatumUtakmice() {
        return datumUtakmice;
    }
    public void setDatumUtakmice(LocalDate datumUtakmice) {
        this.datumUtakmice = datumUtakmice;
    }
    public abstract Long idNatjecanja();
}