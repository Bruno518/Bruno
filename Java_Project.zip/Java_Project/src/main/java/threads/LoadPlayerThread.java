package threads;

import model.entity.Igrac;
import model.entity.SportskiKlub;
import model.enumeration.Aktivnost;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import static com.example.java_project.Database.closeConnection;
import static com.example.java_project.Database.makeConnection;

public class LoadPlayerThread implements Runnable{
    private Map<Long, Igrac> players;
    @Override
    public void run()
    {
        Map<Long, Igrac> players=new HashMap<>();
        Connection connection = makeConnection();

        try (Statement statement = connection.createStatement()) {
            ResultSet set = statement.executeQuery("SELECT * from java_projekt.igrac");
            ResultSetMetaData rsmd = set.getMetaData();

            int brojKolona = rsmd.getColumnCount();
            if(brojKolona<6)
            {
                while (set.next())
                {
                    Igrac i = new Igrac.Builder(set.getString("ime"), set.getString("prezime"))
                            .setBrojIgraca(set.getLong("broj_igraca"))
                            .setBrojOdigranihUtakmica(set.getLong("odigrane_utakmice"))
                            .setBrojGolova(set.getLong("broj_golova"))
                            .setId(set.getLong("id"))
                            .setStatusIgraca(Aktivnost.valueOf(set.getString("aktivnost").toUpperCase())).build();
                    players.put(set.getLong("id"), i);
                }
            }
            else
            {
                while (set.next())
                {
                    Igrac i = new Igrac.Builder(set.getString("ime"), set.getString("prezime"))
                            .setBrojIgraca(set.getLong("broj_igraca"))
                            .setBrojOdigranihUtakmica(set.getLong("odigrane_utakmice"))
                            .setBrojGolova(set.getLong("broj_golova"))
                            .setId(set.getLong("id"))
                            .setIdKluba(set.getLong("id_kluba"))
                            .setStatusIgraca(Aktivnost.valueOf(set.getString("aktivnost").toUpperCase())).build();
                    players.put(set.getLong("id"), i);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeConnection(connection);
        }
        this.players=players;
    }

    public Map<Long, Igrac> getPlayers() {
        return players;
    }
}
