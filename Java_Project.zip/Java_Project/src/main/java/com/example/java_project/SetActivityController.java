package com.example.java_project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import model.entity.Igrac;
import model.entity.Natjecanje;
import model.enumeration.Aktivnost;
import model.interfaces.SetScreen;
import threads.LoadPlayerThread;
import threads.LoadTournamentThread;
import threads.SetActivityThread;

import java.util.Map;
import java.util.Set;

public class SetActivityController implements SetScreen {
    @FXML
    public ComboBox<String> activityCombo;
    @FXML
    public TextField playerName;

    private Map<Long, Igrac> players;

    public void initialize()
    {
        ObservableList<String> list = FXCollections.observableArrayList();

        for (Aktivnost a : Aktivnost.values()) {
            list.add(a.getStatus());
        }
        activityCombo.setItems(list);
        LoadPlayerThread l=new LoadPlayerThread();
        l.run();
        players=l.getPlayers();
    }

    public void saveActivity()
    {
        Boolean b=false;
        for(Igrac i:players.values())
        {
            if(i.getIme().equals(playerName.getText()))
            {
                b=true;
            }
        }
        if(playerName.getText()!=null && activityCombo.getValue()!=null && b)
        {
            SetActivityThread s=new SetActivityThread(activityCombo.getValue(),playerName.getText());
            s.run();

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Success!");
            alert.setContentText("Successful input!");
            alert.setHeaderText(null);
            alert.show();
        }
        else
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please input the correct information!");
            alert.show();
        }
    }

    public void back()
    {
        goBack();
    }
}
