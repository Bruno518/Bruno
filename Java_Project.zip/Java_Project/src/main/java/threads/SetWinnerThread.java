package threads;

import com.example.java_project.Database;
import model.entity.Utakmica;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import static com.example.java_project.Database.closeConnection;

public class SetWinnerThread implements Runnable{
    private String s;
    private Long id;
    public SetWinnerThread(String s, Long id){this.s=s;this.id=id;}

    @Override
    public void run() {
        LoadGameThread l1=new LoadGameThread();
        l1.run();

        Map<Long, Utakmica> games=l1.getGames();

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        for(Utakmica u:games.values())
        {
            if(u.getIdUtakmice().equals(id));
            {
                try {
                    connection = Database.makeConnection();

                    String updateQuery = "UPDATE utakmica SET rez_utakmice = ? WHERE id = ?";
                    preparedStatement = connection.prepareStatement(updateQuery);
                    preparedStatement.setString(1, s);
                    preparedStatement.setLong(2, id);

                    preparedStatement.executeUpdate();

                } catch (SQLException e) {
                    throw new RuntimeException(e);
                } finally {
                    closeConnection(connection);
                }
            }
        }

    }
    }
