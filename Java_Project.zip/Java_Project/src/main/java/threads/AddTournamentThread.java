package threads;

import model.entity.Natjecanje;
import model.interfaces.ObjectWrite;
import model.records.Stadion;

import java.io.IOException;
import java.sql.*;

import static com.example.java_project.Database.closeConnection;
import static com.example.java_project.Database.makeConnection;

public class AddTournamentThread implements Runnable, ObjectWrite {
    private final Natjecanje s;
    public AddTournamentThread(Natjecanje s)
    {
        this.s=s;
    }

    @Override
    public void run() {
        Connection connection = makeConnection();

        try (PreparedStatement preparedStatement = connection.prepareStatement
                ("INSERT INTO java_projekt.natjecanje (ime_nat, dat_pocetka, dat_kraja) values (?,?,?);", Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1, s.getImeNatjecanja());
            preparedStatement.setDate(2, Date.valueOf(s.getDatumPocetka()));
            preparedStatement.setDate(3, Date.valueOf(s.getDatumKraja()));
            preparedStatement.executeUpdate();
            writeObject(s);
        } catch (SQLException | IOException e) {
            throw new RuntimeException(e);
        } finally {
            closeConnection(connection);
        }
    }
}
