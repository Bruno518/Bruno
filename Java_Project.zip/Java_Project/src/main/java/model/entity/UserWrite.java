package model.entity;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class UserWrite {
    public void writeUser(Korisnik k)
    {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/main/java/dat/loggedIn.txt"))) {
            writer.write(k.getnaziv()+":"+k.gethashPass()+":"+k.getRole());
            writer.newLine();
        } catch (
                IOException e) {
            e.printStackTrace();
        }
    }
}
