package model.Exceptions;

public class PasswordMismatchException extends Exception{
    public PasswordMismatchException(String message)
    {
        super(message);
    }
}
