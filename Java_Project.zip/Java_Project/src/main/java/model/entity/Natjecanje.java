package model.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class Natjecanje implements Serializable {

    private Long id_natjecanja;
    private String imeNatjecanja;
    private LocalDate datumPocetka;
    private LocalDate datumKraja;
    private String pobjednik;

    public Natjecanje(Long id_natjecanja, String imeNatjecanja, LocalDate datumPocetka, LocalDate datumKraja) {
        this.id_natjecanja=id_natjecanja;
        this.imeNatjecanja = imeNatjecanja;
        this.datumPocetka = datumPocetka;
        this.datumKraja = datumKraja;
    }

    public String getPobjednik() {
        return pobjednik;
    }

    public Long getId_natjecanja()
    {
        return id_natjecanja;
    }

    public void setPobjednik(String pobjednik) {
        this.pobjednik = pobjednik;
    }

    public String getImeNatjecanja() {
        return imeNatjecanja;
    }

    public void setImeNatjecanja(String imeNatjecanja) {
        this.imeNatjecanja = imeNatjecanja;
    }

    public LocalDate getDatumPocetka() {
        return datumPocetka;
    }

    public void setDatumPocetka(LocalDate datumPocetka) {
        this.datumPocetka = datumPocetka;
    }

    public LocalDate getDatumKraja() {
        return datumKraja;
    }

    public void setDatumKraja(LocalDate datumKraja) {
        this.datumKraja = datumKraja;
    }
}
