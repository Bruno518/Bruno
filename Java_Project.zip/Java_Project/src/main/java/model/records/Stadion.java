package model.records;

import java.io.Serializable;

public record Stadion(Long id, String naziv, String lokacija, Long kapacitet, Long id_domaci_klub) implements Serializable {
    @Override
    public Long id() {
        return id;
    }

    @Override
    public String naziv() {
        return naziv;
    }

    @Override
    public String lokacija() {
        return lokacija;
    }

    @Override
    public Long kapacitet() {
        return kapacitet;
    }

    @Override
    public Long id_domaci_klub() {
        return id_domaci_klub;
    }
}
