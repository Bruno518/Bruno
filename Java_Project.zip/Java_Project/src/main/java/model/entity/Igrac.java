package model.entity;

import model.enumeration.Aktivnost;
import model.interfaces.BrojGolova;

import java.io.Serializable;

public final class Igrac implements BrojGolova, Serializable {
    private Long id;

    private final String ime;
    private final String prezime;
    private Long brojIgraca;
    private Long brojOdigranihUtakmica;
    private Long brojGolova;
    private Aktivnost statusIgraca;
    private Long id_kluba;

    private Igrac(Builder builder) {
        this.id = builder.id;
        this.ime = builder.ime;
        this.prezime = builder.prezime;
        this.brojIgraca = builder.brojIgraca;
        this.brojOdigranihUtakmica = builder.brojOdigranihUtakmica;
        this.brojGolova = builder.brojGolova;
        this.statusIgraca = builder.statusIgraca;
        this.id_kluba = builder.id_kluba;
    }

    public static class Builder {
        private Long id;
        private final String ime;
        private final String prezime;
        private Long brojIgraca;
        private Long brojOdigranihUtakmica;
        private Long brojGolova;
        private Aktivnost statusIgraca;
        private Long id_kluba;

        public Builder(String ime, String prezime) {
            this.ime = ime;
            this.prezime = prezime;
        }

        public Builder setId(Long id) {
            this.id = id;
            return this;
        }

        public Builder setBrojIgraca(Long brojIgraca) {
            this.brojIgraca = brojIgraca;
            return this;
        }

        public Builder setBrojOdigranihUtakmica(Long brojOdigranihUtakmica) {
            this.brojOdigranihUtakmica = brojOdigranihUtakmica;
            return this;
        }

        public Builder setBrojGolova(Long brojGolova) {
            this.brojGolova = brojGolova;
            return this;
        }

        public Builder setStatusIgraca(Aktivnost statusIgraca) {
            this.statusIgraca = statusIgraca;
            return this;
        }

        public Builder setIdKluba(Long id_kluba) {
            this.id_kluba = id_kluba;
            return this;
        }

        public Igrac build() {
            return new Igrac(this);
        }
    }

    public Long getId() {
        return id;
    }

    public String getIme() {
        return ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public Long getBrojIgraca() {
        return brojIgraca;
    }

    public Long getBrojOdigranihUtakmica() {
        return brojOdigranihUtakmica;
    }

    public Long getBrojGolova() {
        return brojGolova;
    }

    public Aktivnost getStatusIgraca() {
        return statusIgraca;
    }

    public Long getIdKluba() {
        return id_kluba;
    }


    @Override
    public Double brojGolova() {
        return (double)(brojGolova/brojOdigranihUtakmica);
    }
}
