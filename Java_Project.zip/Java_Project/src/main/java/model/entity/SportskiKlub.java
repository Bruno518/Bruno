package model.entity;


import java.io.Serializable;

public class SportskiKlub implements Serializable {
    private Long id;
    private String naziv;

    public SportskiKlub(Long id, String naziv) {
        this.id=id;
        this.naziv = naziv;
    }

    public Long getId() {
        return id;
    }

    public SportskiKlub(String naziv) {
        this.naziv = naziv;
    }

    public String getNaziv() {
        return naziv;
    }

}

