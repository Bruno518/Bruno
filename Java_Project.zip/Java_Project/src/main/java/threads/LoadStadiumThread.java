package threads;

import model.entity.SportskiKlub;
import model.records.Stadion;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import static com.example.java_project.Database.closeConnection;
import static com.example.java_project.Database.makeConnection;

public class LoadStadiumThread implements Runnable{
    private Map<Long, Stadion> stadions;
    @Override
    public void run()
    {
        Map<Long, Stadion> stadions=new HashMap<>();
        Connection connection = makeConnection();

        try (Statement statement = connection.createStatement()) {
            ResultSet set = statement.executeQuery("SELECT * from java_projekt.stadion");

            while (set.next()) {
                stadions.put(set.getLong("id"),new Stadion(set.getLong("id"),
                        set.getString("naziv"),set.getString("lokacija"),
                        set.getLong("kapacitet"),set.getLong("id_domaci_klub")));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeConnection(connection);
        }
        this.stadions=stadions;
    }

    public Map<Long, Stadion> getStadion() {
        return stadions;
    }
}
