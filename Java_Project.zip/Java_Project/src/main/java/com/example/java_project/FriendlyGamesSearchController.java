package com.example.java_project;

import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.entity.NatjecateljskaUtakmica;
import model.entity.PrijateljskaUtakmica;
import model.entity.Utakmica;
import model.interfaces.SetScreen;
import model.records.Stadion;
import threads.LoadGameThread;
import threads.LoadStadiumThread;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Map;
import java.util.stream.Collectors;

public class FriendlyGamesSearchController implements SetScreen
{
    @FXML
    public TableView<PrijateljskaUtakmica> friendlyGamesTable;
    @FXML
    public TableColumn<PrijateljskaUtakmica, Long> idCol;
    @FXML
    public TableColumn<PrijateljskaUtakmica, String> clubsCol;
    @FXML
    public TableColumn<PrijateljskaUtakmica, String> dateCol;
    @FXML
    public TableColumn<PrijateljskaUtakmica, String> resultCol;
    @FXML
    public TableColumn<PrijateljskaUtakmica, String> stadiumCol;
    private Map<Long, Stadion> stadiums;

    public void initialize()
    {
        LoadStadiumThread l=new LoadStadiumThread();
        l.run();
        stadiums=l.getStadion();
        LoadGameThread l1=new LoadGameThread();
        l1.run();
        ObservableList<Utakmica> list = FXCollections.observableArrayList( l1.getGames().values());

        ObservableList<PrijateljskaUtakmica> filteredList = list.stream()
                .filter(utakmica -> utakmica.getVrstaUtakmice().equals("p") )
                .map(utakmica -> (PrijateljskaUtakmica) utakmica)
                .collect(Collectors.collectingAndThen(
                        Collectors.toList(),
                        FXCollections::observableArrayList
                ));
        idCol.setCellValueFactory(cellData -> {
            PrijateljskaUtakmica u = cellData.getValue();
            Long id = u.getIdUtakmice();

            return new SimpleObjectProperty<>(id);
        });
        clubsCol.setCellValueFactory(cellData -> {
            PrijateljskaUtakmica u = cellData.getValue();
            String club1Name = u.getSportskiKlub1().getNaziv();
            String club2Name=u.getSportskiKlub2().getNaziv();
            String combinedDate = club1Name + " vs " + club2Name;
            return new SimpleStringProperty(combinedDate);
        });

        dateCol.setCellValueFactory(cellData -> {
            PrijateljskaUtakmica u = cellData.getValue();
            LocalDate date = u.getDatumUtakmice();
            return new SimpleStringProperty(String.valueOf(date));
        });

        resultCol.setCellValueFactory(cellData -> {
            PrijateljskaUtakmica u = cellData.getValue();
            if (u.getRezultatUtakmice()==null)
            {
                return new SimpleStringProperty("Game Not Played");
            }
            else
            {
                return new SimpleStringProperty(u.getRezultatUtakmice());
            }
        });

        stadiumCol.setCellValueFactory(cellData -> {
            PrijateljskaUtakmica u = cellData.getValue();
            return new SimpleStringProperty(stadiums.get(u.getIdStadiona()).naziv());
        });
        friendlyGamesTable.setItems(filteredList);
    }

    public void back()
    {
        goBack();
    }
}
