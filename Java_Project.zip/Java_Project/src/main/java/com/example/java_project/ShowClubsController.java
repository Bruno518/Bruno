package com.example.java_project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.entity.Natjecanje;
import model.entity.SportskiKlub;
import model.interfaces.SetScreen;
import threads.LoadClubThread;

import java.util.Map;

public class ShowClubsController implements SetScreen {
    @FXML
    public TableView<SportskiKlub> clubTable;
    @FXML
    public TableColumn<SportskiKlub,Long> idCol;
    @FXML
    public TableColumn<SportskiKlub, String> nameCol;

    public void initialize()
    {
        LoadClubThread l=new LoadClubThread();
        l.run();

        ObservableList<SportskiKlub> clubList= FXCollections.observableArrayList(l.getClubs().values());

        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameCol.setCellValueFactory(new PropertyValueFactory<>("naziv"));
        clubTable.setItems(clubList);
    }

    public void back()
    {
        goBack();
    }
}
