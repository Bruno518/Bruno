package threads;

import com.example.java_project.Database;
import model.entity.Natjecanje;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import static com.example.java_project.Database.closeConnection;

public class SetActivityThread implements Runnable{
    private String s;
    private String name;
    public SetActivityThread(String s, String name){this.s=s;this.name=name;}

    @Override
    public void run() {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
                try {
                    connection = Database.makeConnection();

                    String updateQuery = "UPDATE igrac SET aktivnost = ? WHERE ime = ?";
                    preparedStatement = connection.prepareStatement(updateQuery);
                    preparedStatement.setString(1, s);
                    preparedStatement.setString(2, name);

                    preparedStatement.executeUpdate();

                } catch (SQLException e) {
                    throw new RuntimeException(e);
                } finally {
                    closeConnection(connection);
                }
    }
}
