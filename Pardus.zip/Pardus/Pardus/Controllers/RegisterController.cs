﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pardus.Models;

public class RegisterController : Controller
{
    private readonly PardusDbContext _context;

    public RegisterController(PardusDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (ModelState.IsValid)
        {
            if (await _context.Users.AnyAsync(u => u.username == model.Username))
            {
                ModelState.AddModelError("", "Username is already taken.");
                return View(model);
            }

            if (await _context.Users.AnyAsync(u => u.email == model.Email))
            {
                ModelState.AddModelError("", "Email is already registered.");
                return View(model);
            }

            int maxId = _context.Users.Any() ? await _context.Users.MaxAsync(u => u.id) : 0;

            var user = new Users
            {
                id = maxId++,
                username = model.Username,
                email = model.Email,
                password = model.Password
            };

            try
            {
                _context.Users.Add(user);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                ModelState.AddModelError("", "An error occurred while saving the user.");
                return View(model);
            }

            return RedirectToAction("Home", "Login");
        }
        else
        {
            foreach (var modelError in ModelState.Values.SelectMany(v => v.Errors))
            {
            Console.WriteLine(modelError.ErrorMessage);
            }
            return View(model);
        }
    }
}
