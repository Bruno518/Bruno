package com.example.java_project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import model.entity.Igrac;
import model.entity.SportskiKlub;
import model.enumeration.Aktivnost;
import model.interfaces.SetScreen;
import threads.AddClubThread;
import threads.AddPlayerThread;
import threads.LoadClubThread;
import threads.LoadPlayerThread;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class AddPlayerController implements SetScreen {
    @FXML
    public TextField nameText;
    @FXML
    public TextField lastNameText;
    @FXML
    public TextField numberText;
    @FXML
    public TextField playedGamesText;
    @FXML
    public TextField goalsText;
    @FXML
    public ComboBox<String> clubsCombo;
    private Map<Long, SportskiKlub> clubs=new HashMap<>();

    @FXML
    public void initialize()
    {
        LoadClubThread clubLoad=new LoadClubThread();
        clubLoad.run();
         clubs=clubLoad.getClubs();

        ObservableList<String> list = FXCollections.observableArrayList();

        for (SportskiKlub club : clubs.values()) {
            list.add(club.getNaziv());
        }
         clubsCombo.setItems(list);
    }
    public void savePlayer()
    {
        if(nameText.getText().isEmpty()||lastNameText.getText().isEmpty()||numberText.getText().isEmpty()||playedGamesText.getText().isEmpty()||goalsText.getText().isEmpty()||clubsCombo.getValue()==null)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please input the player information!");
            alert.show();
        }
        else
        {
            Igrac i;

            if(clubsCombo.getValue()==null)
            {
                i=new Igrac.Builder(nameText.getText(),lastNameText.getText())
                        .setBrojGolova(Long.valueOf(goalsText.getText()))
                        .setBrojIgraca(Long.valueOf(numberText.getText()))
                        .setBrojOdigranihUtakmica(Long.valueOf(playedGamesText.getText()))
                        .setStatusIgraca(Aktivnost.AKTIVAN).build();
            }
            else
            {
                Long id= 0L;
                for(Long l:clubs.keySet())
                {
                    if(clubs.get(l).getNaziv().equals(clubsCombo.getValue()))
                    {
                        id=l;
                    }
                }
                i=new Igrac.Builder(nameText.getText(),lastNameText.getText())
                        .setBrojGolova(Long.valueOf(goalsText.getText()))
                        .setBrojIgraca(Long.valueOf(numberText.getText()))
                        .setBrojOdigranihUtakmica(Long.valueOf(playedGamesText.getText()))
                        .setStatusIgraca(Aktivnost.AKTIVAN).setIdKluba(id).build();
            }
            AddPlayerThread a=new AddPlayerThread(i);
            a.run();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Success!");
            alert.setContentText("Successful input!");
            alert.setHeaderText(null);
            alert.show();
        }
    }
    public void back()
    {
        goBack();
    }
}
