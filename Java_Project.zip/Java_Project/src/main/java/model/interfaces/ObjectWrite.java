package model.interfaces;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public interface ObjectWrite{

     default <T> void writeObject(T obj) throws IOException
     {
        ObjectOutputStream viewingTeam = new ObjectOutputStream(new FileOutputStream("src/main/java/dat/serialization.dat"));
            viewingTeam.writeObject(obj);
    }
}
