﻿using Microsoft.EntityFrameworkCore;
namespace Pardus.Models
{
    public class PardusDbContext : DbContext
    {
        public PardusDbContext(DbContextOptions<PardusDbContext> options) : base(options) { }

        public DbSet<Users> Users { get; set; }
        public DbSet<BlogPosts> BlogPosts { get; set; }
        public DbSet<Comments> Comments { get; set; }
    }
}
