package threads;

import model.entity.Natjecanje;
import model.records.Stadion;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import static com.example.java_project.Database.closeConnection;
import static com.example.java_project.Database.makeConnection;

public class LoadTournamentThread implements Runnable{
    private Map<Long, Natjecanje> tournaments;
    @Override
    public void run()
    {
        Map<Long, Natjecanje> tournaments=new HashMap<>();
        Connection connection = makeConnection();

        try (Statement statement = connection.createStatement()) {
            ResultSet set = statement.executeQuery("SELECT * from java_projekt.natjecanje");
            String p;
            while (set.next()) {
                Natjecanje natjecanje = new Natjecanje(
                        set.getLong("id"),
                        set.getString("ime_nat"),
                        set.getDate("dat_pocetka").toLocalDate(),
                        set.getDate("dat_kraja").toLocalDate());
                        natjecanje.setPobjednik(set.getString("pobjednik"));

                        tournaments.put(set.getLong("id"), natjecanje);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeConnection(connection);
        }
        this.tournaments=tournaments;
    }

    public Map<Long, Natjecanje> getTournaments() {
        return tournaments;
    }
}
