module com.example.java_project {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires org.slf4j;

    opens com.example.java_project to javafx.fxml;
    opens model.entity to javafx.base;
    exports com.example.java_project;
}