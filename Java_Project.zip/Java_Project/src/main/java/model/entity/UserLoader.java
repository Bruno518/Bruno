package model.entity;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class UserLoader {

    public Map<String, Korisnik> loadUsers(String filePath) {
        Map<String, Korisnik> korisnici = new HashMap<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath)))
        {
            String line;
            while ((line = reader.readLine()) != null)
            {
                String[] parts = line.split(":");
                if (parts.length == 3)
                {
                    String username = parts[0];
                    String hashedPassword = parts[1];
                    String role = parts[2];
                    korisnici.put(username, new Korisnik(username, hashedPassword, role));
                }
            }
        } catch (IOException e)
        {
            e.printStackTrace();
        }
        return korisnici;
    }
}
