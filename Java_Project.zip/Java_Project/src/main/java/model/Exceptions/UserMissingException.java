package model.Exceptions;

public class UserMissingException extends Exception{
    public UserMissingException(String message)
    {
        super(message);
    }
}
