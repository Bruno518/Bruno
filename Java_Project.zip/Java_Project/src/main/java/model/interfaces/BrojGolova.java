package model.interfaces;

import model.entity.Igrac;

public sealed interface BrojGolova permits Igrac {
    public Double brojGolova();
}
