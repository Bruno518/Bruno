package model.entity;

import java.io.Serializable;
import java.time.LocalDate;

public class PrijateljskaUtakmica extends Utakmica implements Serializable {
    public PrijateljskaUtakmica(Long id, SportskiKlub sportskiKlub1, SportskiKlub sportskiKlub2, LocalDate datumUtakmice, Long idStadion) {
        super(id, sportskiKlub1, sportskiKlub2, datumUtakmice, idStadion);
    }

    @Override
    public String getVrstaUtakmice() {
        return "p";
    }

    @Override
    public Long idNatjecanja() {
        return null;
    }
}