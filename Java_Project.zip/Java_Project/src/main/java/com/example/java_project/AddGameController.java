package com.example.java_project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import model.entity.*;
import model.interfaces.ObjectWrite;
import model.interfaces.SetScreen;
import model.records.Stadion;
import threads.*;

import java.io.IOException;
import java.util.Map;
import java.util.Optional;

public class AddGameController implements SetScreen {
    @FXML
    public ComboBox<String> firstCombo;
    @FXML
    public ComboBox<String> secondCombo;
    @FXML
    public DatePicker gameDate;
    @FXML
    public CheckBox typeBox;
    @FXML
    public ComboBox<String> tourCombo;
    @FXML
    public ComboBox<String> stadiumCombo;
    @FXML
    public Label tourLabel;

    private Map<Long, SportskiKlub> clubs;
    private Map<Long, Utakmica> games;
    private Map<Long, Natjecanje> tournaments;
    private Map<Long, Stadion> stadiums;

    public void initialize()
    {
        tourCombo.setVisible(false);
        tourLabel.setVisible(false);

        LoadClubThread l1=new LoadClubThread();
        LoadTournamentThread l2=new LoadTournamentThread();
        LoadGameThread l3=new LoadGameThread();
        LoadStadiumThread l4=new LoadStadiumThread();
        l1.run();
        l2.run();
        l3.run();
        l4.run();

        clubs=l1.getClubs();
        tournaments=l2.getTournaments();
        games=l3.getGames();
        stadiums=l4.getStadion();

        ObservableList<String> list = FXCollections.observableArrayList();
        for (SportskiKlub club : clubs.values()) {
            list.add(club.getNaziv());
        }
        firstCombo.setItems(list);
        secondCombo.setItems(list);

        ObservableList<String> list1 = FXCollections.observableArrayList();

        for (Natjecanje tour : tournaments.values()) {
            list1.add(tour.getImeNatjecanja());
        }
        tourCombo.setItems(list1);

        ObservableList<String> list2 = FXCollections.observableArrayList();

        for (Stadion stad : stadiums.values()) {
            list2.add(stad.naziv());
        }
        stadiumCombo.setItems(list2);
    }
    public void showTour()
    {
        if(typeBox.isSelected())
        {
            tourCombo.setVisible(true);
            tourLabel.setVisible(true);
        }
        else
        {
            tourCombo.setVisible(false);
            tourLabel.setVisible(false);
        }
    }
    public void saveGame()
    {


        Optional<Long> maxId = games.keySet()
                .stream()
                .max(Long::compareTo);

        Long club1=0L;
        Long club2=0L;
        Long tourID=0L;
        Long stadiumID=0L;
        for(Long l:tournaments.keySet())
        {
            if(tournaments.get(l).getImeNatjecanja().equals(tourCombo.getValue()))
            {
                tourID=l;
            }
        }
        for(Long l:stadiums.keySet())
        {
            if(stadiums.get(l).naziv().equals(stadiumCombo.getValue()))
            {
                stadiumID=l;
            }
        }
        for(Long l:clubs.keySet())
        {
            if(clubs.get(l).getNaziv().equals(firstCombo.getValue()))
            {
                club1=l;
            }
            if(clubs.get(l).getNaziv().equals(secondCombo.getValue()))
            {
                club2=l;
            }
        }

        if(firstCombo.getValue()==null || secondCombo.getValue()==null || gameDate.getValue()==null || firstCombo.getValue().equals(secondCombo.getValue())||stadiumCombo.getValue()==null)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please input the correct game information!");
            alert.show();
        }
        else if(typeBox.isSelected())
        {
            if(tourCombo.getValue()==null)
            {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Please input the game information!");
                alert.show();
            }
            else
            {
                AddGameThread g=new AddGameThread(new NatjecateljskaUtakmica(maxId.orElse(1L), clubs.get(club1), clubs.get(club2),gameDate.getValue(),tourID,stadiumID));
                g.run();
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Success!");
                alert.setContentText("Successful input!");
                alert.setHeaderText(null);
                alert.show();
            }
        }
        else
        {
            AddGameThread g=new AddGameThread(new PrijateljskaUtakmica(maxId.orElse(1L), clubs.get(club1), clubs.get(club2),gameDate.getValue(),stadiumID));
            g.run();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Success!");
            alert.setContentText("Successful input!");
            alert.setHeaderText(null);
            alert.show();
        }
    }

    public void back()
    {
        goBack();
    }
}
