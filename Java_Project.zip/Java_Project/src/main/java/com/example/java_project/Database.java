package com.example.java_project;
import java.sql.*;

public class Database {
    private static boolean activeConnectionWithDB;

    public static synchronized Connection makeConnection() {
        synchronized (Database.class){
            while(activeConnectionWithDB)
            {
                try {
                    Database.class.wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        String url = "jdbc:mysql://localhost:3306/java_projekt";
        String username = "root";
        String password = "2543";

        try {
            activeConnectionWithDB=true;
            return DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            throw new IllegalStateException("Cannot connect the database!", e);
        }

    }

    public static void closeConnection(Connection connection){
        synchronized (Database.class) {
            try {
                connection.close();

            } catch (SQLException e) {
                throw new RuntimeException(e);
            } finally {
                activeConnectionWithDB = false;
                Database.class.notifyAll();
            }
        }
    }
}
