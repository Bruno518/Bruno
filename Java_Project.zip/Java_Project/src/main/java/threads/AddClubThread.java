package threads;

import model.entity.SportskiKlub;

import java.io.IOException;
import java.sql.*;
import model.interfaces.ObjectWrite;

import static com.example.java_project.Database.closeConnection;
import static com.example.java_project.Database.makeConnection;

public class AddClubThread implements Runnable, ObjectWrite {
    private final SportskiKlub s;
    public AddClubThread(SportskiKlub s)
    {
        this.s=s;
    }

    @Override
    public void run()
    {
        Connection connection = makeConnection();

        try (PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO java_projekt.sportski_klub (ime_kluba) values (?);", Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1,s.getNaziv());
            preparedStatement.executeUpdate();
            writeObject(s);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            closeConnection(connection);
        }

    }
}
