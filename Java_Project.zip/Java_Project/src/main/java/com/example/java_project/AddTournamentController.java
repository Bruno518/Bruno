package com.example.java_project;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import model.entity.Natjecanje;
import model.interfaces.SetScreen;
import threads.AddTournamentThread;
import threads.LoadTournamentThread;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;

public class AddTournamentController implements SetScreen {
    @FXML
    public TextField nameText;
    @FXML
    public DatePicker startDateText;
    @FXML
    public DatePicker endDateText;
    private Map<Long,Natjecanje> tournaments;

    public void initialize()
    {
        LoadTournamentThread l=new LoadTournamentThread();
        l.run();
        tournaments=l.getTournaments();
    }

    public void saveTournament()
    {
        if(nameText.getText().isEmpty() || startDateText.getValue()==null || endDateText.getValue()==null)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please input the tournament information!");
            alert.show();
        }
        else
        {
            Optional<Long> maxId = tournaments.keySet()
                    .stream()
                    .max(Long::compareTo);
            AddTournamentThread t = new AddTournamentThread(new Natjecanje(maxId.orElse(1L),nameText.getText(),
                    startDateText.getValue(),endDateText.getValue()));
            t.run();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Success!");
            alert.setContentText("Successful input!");
            alert.setHeaderText(null);
            alert.show();
        }
    }

    public void back()
    {
        goBack();
    }
}
