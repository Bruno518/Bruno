package com.example.java_project;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import model.interfaces.SetScreen;
import threads.SetWinnerThread;

import java.io.IOException;
import java.util.Objects;

public class SetGameWinnerController implements SetScreen {
    @FXML
    public TextField gameId;
    @FXML
    public TextField gameResult;

    public void setWinner()
    {
        if(gameId.getText().isEmpty() || gameResult.getText().isEmpty())
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please input the correct information!");
            alert.show();

        }
        else{
            SetWinnerThread s = new SetWinnerThread(gameResult.getText(), Long.valueOf(gameId.getText()));
            s.run();

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Success!");
            alert.setContentText("Successful input!");
            alert.setHeaderText(null);
            alert.show();
        }

    }
    public void back()
    {
        goBack();
    }
}
