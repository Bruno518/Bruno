package com.example.java_project;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import model.Exceptions.UserMissingException;
import model.encryption.PassEncryption;
import model.entity.Korisnik;
import model.entity.UserLoader;
import model.entity.UserWrite;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class HelloController
{
    private static final Logger logger= LoggerFactory.getLogger(HelloController.class);
    @FXML
    public TextField userText;
    @FXML
    private TextField passText;
    private Map<String, Korisnik> korisnici = new HashMap<>();
    @FXML
    public void initialize()
    {
        UserLoader userLoader = new UserLoader();
        korisnici = userLoader.loadUsers("src/main/java/dat/users.txt");
        }
    public void loginButton() {
            String username = userText.getText();
            String pass = passText.getText();

        try {
            checkUser(username,pass);

            UserWrite writer=new UserWrite();
            writer.writeUser(korisnici.get(username));

            FXMLLoader fxmlLoader =
            new FXMLLoader(HelloApplication.class.getResource(
                    "home.fxml"));
            Scene scene = null;
            scene = new Scene(fxmlLoader.load(), 680, 740);

            HelloApplication.getStage().setScene(scene);
            HelloApplication.getStage().show();
            }
        catch (UserMissingException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("User doesn't exist!");
            alert.setHeaderText(null);
            alert.setContentText(e.getMessage());
            logger.error("User doesn't exist!");
            alert.showAndWait();
        } catch (NoSuchPaddingException | InvalidKeyException | BadPaddingException | InvalidAlgorithmParameterException | IllegalBlockSizeException | NoSuchAlgorithmException e) {
            logger.error("Password crypt error");
            throw new RuntimeException(e);
        } catch (IOException e) {
            logger.error("Unkown error! "+e.getMessage());
            throw new RuntimeException(e);
        }
    }
    public void registerButton()
    {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("register.fxml"));
        Scene scene = null;
        try {
                scene = new Scene(fxmlLoader.load(), 600, 400);
            } catch (IOException e) {
                e.printStackTrace();
            }

        HelloApplication.getStage().setScene(scene);
        HelloApplication.getStage().show();
    }
    public void checkUser(String username, String password) throws UserMissingException, InvalidAlgorithmParameterException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, BadPaddingException, InvalidKeyException {
        if(username.isEmpty() || password.isEmpty() || korisnici.get(username)==null)
        {
            throw new UserMissingException("User doesn't exists!");
        }
        else
        {
            final var crypt = new PassEncryption();
            final var decrypted = crypt.decrypt(korisnici.get(username).gethashPass());
            if (!korisnici.get(username).getnaziv().equals(username) || !password.equals(decrypted)) {
                throw new UserMissingException("User doesn't exists!");
            }
        }
    }
}