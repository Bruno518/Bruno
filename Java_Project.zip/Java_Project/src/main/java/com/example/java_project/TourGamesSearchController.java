package com.example.java_project;

import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.entity.*;
import model.interfaces.SetScreen;
import model.records.Stadion;
import threads.LoadGameThread;
import threads.LoadStadiumThread;
import threads.LoadTournamentThread;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.Map;
import java.util.stream.Collectors;

public class TourGamesSearchController implements SetScreen
{
    @FXML
    public ComboBox<String> tourCombo;
    @FXML
    public TableView<NatjecateljskaUtakmica> gameTable;
    @FXML
    public TableColumn<NatjecateljskaUtakmica,Long> idCol;
    @FXML
    public TableColumn<NatjecateljskaUtakmica,String> club1Col;
    @FXML
    public TableColumn<NatjecateljskaUtakmica,String> dateCol;
    @FXML
    public  TableColumn<NatjecateljskaUtakmica,String> resultCol;
    @FXML
    public TableColumn<NatjecateljskaUtakmica, String> stadiumCol;
    private Map<Long, Natjecanje> tours;
    private Map<Long, Stadion> stadiums;

    public void initialize()
    {
        LoadStadiumThread l=new LoadStadiumThread();
        l.run();
        stadiums=l.getStadion();
        LoadTournamentThread l1=new LoadTournamentThread();
        l1.run();
        tours=l1.getTournaments();

        ObservableList<String> list1 = FXCollections.observableArrayList();

        for (Natjecanje tour : tours.values()) {
            list1.add(tour.getImeNatjecanja());
        }
        tourCombo.setItems(list1);

        tourCombo.setOnAction(e -> filterMatches(tourCombo.getValue()));
    }

    public void filterMatches(String tour)
    {
        LoadGameThread l=new LoadGameThread();
        l.run();
        ObservableList<Utakmica> list = FXCollections.observableArrayList( l.getGames().values());

        ObservableList<NatjecateljskaUtakmica> filteredList = list.stream()
                .filter(utakmica -> utakmica.getVrstaUtakmice().equals("n") &&
                        tours.get(utakmica.idNatjecanja()).getImeNatjecanja().equals(tour))
                .map(utakmica -> (NatjecateljskaUtakmica) utakmica)
                .collect(Collectors.collectingAndThen(
                        Collectors.toList(),
                        FXCollections::observableArrayList
                ));

        idCol.setCellValueFactory(cellData -> {
            NatjecateljskaUtakmica u = cellData.getValue();
            Long id = u.getIdUtakmice();

            return new SimpleObjectProperty<>(id);
        });
        club1Col.setCellValueFactory(cellData -> {
            NatjecateljskaUtakmica u = cellData.getValue();

            String club1Name = u.getSportskiKlub1().getNaziv();
            String club2Name=u.getSportskiKlub2().getNaziv();
            String combinedDate = club1Name + " vs " + club2Name;

            return new SimpleStringProperty(combinedDate);
        });

        dateCol.setCellValueFactory(cellData -> {
            NatjecateljskaUtakmica u = cellData.getValue();
            LocalDate date = u.getDatumUtakmice();
            return new SimpleStringProperty(String.valueOf(date));
        });

        resultCol.setCellValueFactory(cellData -> {
            NatjecateljskaUtakmica u = cellData.getValue();
            if (u.getRezultatUtakmice()==null)
            {
                return new SimpleStringProperty("Game Not Played");
            }
            else
            {
                return new SimpleStringProperty(u.getRezultatUtakmice());
            }
        });

        stadiumCol.setCellValueFactory(cellData -> {
            NatjecateljskaUtakmica u = cellData.getValue();

            return new SimpleStringProperty(stadiums.get(u.getIdStadiona()).naziv());
        });
        gameTable.setItems(filteredList);
    }
    public void back()
    {
        goBack();
    }
}
