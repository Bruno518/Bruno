package com.example.java_project;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import model.entity.Korisnik;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;
import model.entity.Natjecanje;
import model.entity.UserLoader;
import model.interfaces.SetScreen;
import threads.LoadTournamentThread;

public class HomeController implements SetScreen {
    @FXML
    public MenuButton adminMenu;
    @FXML
    public TableView<Natjecanje> tableView = new TableView<>();
    @FXML
    public TableColumn<Natjecanje, String> tourNameCol;
    @FXML
    public TableColumn<Natjecanje, String> tourDate;
    @FXML
    public TableColumn<Natjecanje, String> winnerCol;


    @FXML
    public void initialize()
    {
        LoadTournamentThread l1=new LoadTournamentThread();
        l1.run();

        ObservableList<Natjecanje> tourList= FXCollections.observableArrayList(l1.getTournaments().values());

        tourNameCol.setCellValueFactory(new PropertyValueFactory<>("imeNatjecanja"));
        tourDate.setCellValueFactory(cellData -> {
            Natjecanje natjecanje = cellData.getValue();
            LocalDate datumPocetka = natjecanje.getDatumPocetka();
            LocalDate datumKraja = natjecanje.getDatumKraja();

            String combinedDate = datumPocetka + " - " + datumKraja;

            return new SimpleStringProperty(combinedDate);
        });

        winnerCol.setCellValueFactory(cellData -> {
            Natjecanje natjecanje = cellData.getValue();
            if(natjecanje.getPobjednik()==null)
            {
                return new SimpleStringProperty("Tournament in progress!");
            }
            else
            {
                return new SimpleStringProperty(natjecanje.getPobjednik());

            }
        });
        tableView.setItems(tourList);

        UserLoader userLoad=new UserLoader();
        Map<String, Korisnik> user;
        user=userLoad.loadUsers("src/main/java/dat/loggedIn.txt");
        Boolean admin=user.values().stream().findFirst().get().getRole().equals("a");
        adminMenu.setVisible(admin);
    }
    public void addClub()
    {
        screen("addClub.fxml");
    }
    public void addGame()
    {
        screen("addGame.fxml");
    }
    public void addPlayer()
    {
        screen("addPlayer.fxml");
    }
    public void addStadium()
    {
        screen("addStadium.fxml");
    }
    public void tourGamesSearch()
    {
        screen("tourGamesSearch.fxml");
    }
    public void setGameWinner()
    {
        screen("setGameWinner.fxml");
    }
    public void showPlayers()
    {
        screen("showPlayers.fxml");
    }
    public void showClubs()
    {
        screen("showClubs.fxml");
    }
    public void setTourWinner()
    {
        screen("setTourWinner.fxml");
    }
    public void showFriendlyGames()
    {
        screen("friendlyGamesSearch.fxml");
    }
    public void addTournament()
    {
        screen("addTournament.fxml");
    }

    public void setActivity()
    {
        screen("setActivity.fxml");
    }

    public void deleteTour()
    {
        screen("DeleteTournament.fxml");
    }
    public void logOutButton()
    {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Logout");
        alert.setHeaderText("You are about to log out.");
        alert.setContentText("Are you sure you want to log out?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            screen("hello-view.fxml");
        }
    }
}
