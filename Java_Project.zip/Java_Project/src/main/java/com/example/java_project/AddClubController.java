package com.example.java_project;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import model.entity.SportskiKlub;
import model.interfaces.SetScreen;
import threads.AddClubThread;
import threads.LoadClubThread;

import java.io.IOException;
import java.util.Map;

public class AddClubController implements SetScreen {
    @FXML
    public TextField nameText;
    public void saveClub()
    {
        LoadClubThread clubLoad=new LoadClubThread();
        clubLoad.run();
        Map<Long, SportskiKlub> clubs=clubLoad.getClubs();
        if(nameText.getText().isEmpty())
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("Please input the desired club name!");
            alert.setHeaderText(null);
            alert.show();
        }
        else
        {
            AddClubThread addClub = new AddClubThread(new SportskiKlub(nameText.getText()));
            addClub.run();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Success!");
            alert.setContentText("Successful input!");
            alert.setHeaderText(null);
            alert.show();
        }
    }
    public void back()
    {
        goBack();
    }
}
