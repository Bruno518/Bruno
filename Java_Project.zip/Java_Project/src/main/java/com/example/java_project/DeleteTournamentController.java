package com.example.java_project;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import model.interfaces.SetScreen;
import threads.DeleteTournamentThread;

import java.io.IOException;

public class DeleteTournamentController implements SetScreen {
    @FXML
    public TextField nameText;
    public void deleteTour()
    {
        if((nameText.getText())==null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please input the correct information!");
            alert.show();

        }
        else
        {
            DeleteTournamentThread d=new DeleteTournamentThread(nameText.getText());
            d.run();
        }
    }
    public void back()
    {
        goBack();
    }
}
