﻿using System.ComponentModel.DataAnnotations;

namespace Pardus.Models
{
    public class Comments
    {
        [Key]
        public int id { get; set; }
        public required string comment { get; set; }
        public required int post_id { get; set; }
        public required int user_id { get; set; }
        public required DateTime created_at { get; set; }
        public required DateTime updated_at { get; set; }
    }
}
