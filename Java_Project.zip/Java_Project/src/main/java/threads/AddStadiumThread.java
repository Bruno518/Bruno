package threads;

import model.entity.Igrac;
import model.interfaces.ObjectWrite;
import model.records.Stadion;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import static com.example.java_project.Database.closeConnection;
import static com.example.java_project.Database.makeConnection;

public class AddStadiumThread implements Runnable, ObjectWrite {
    private final Stadion s;
    public AddStadiumThread(Stadion s)
    {
        this.s=s;
    }

    @Override
    public void run() {
        Connection connection = makeConnection();

            try (PreparedStatement preparedStatement = connection.prepareStatement
                    ("INSERT INTO java_projekt.stadion (naziv, lokacija, kapacitet, id_domaci_klub) values (?,?,?,?);", Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setString(1, s.naziv());
                preparedStatement.setString(2, s.lokacija());
                preparedStatement.setLong(3, s.kapacitet());
                preparedStatement.setLong(4, s.id_domaci_klub());
                preparedStatement.executeUpdate();
                writeObject(s);
            } catch (SQLException | IOException e) {
                throw new RuntimeException(e);
            } finally {
                closeConnection(connection);
            }

    }
}
