package com.example.java_project;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import model.entity.SportskiKlub;
import model.interfaces.SetScreen;
import model.records.Stadion;
import threads.AddStadiumThread;
import threads.LoadClubThread;
import threads.LoadStadiumThread;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class AddStadiumController implements SetScreen {
    @FXML
    public TextField nameText;
    @FXML
    public TextField locationText;
    @FXML
    public TextField capacityText;
    @FXML
    public ComboBox<String> homeClubCombo;
    Map<Long, SportskiKlub> clubs=new HashMap<>();
    Map<Long, Stadion> stadions=new HashMap<>();
    @FXML
    public void initialize()
    {
        LoadClubThread l=new LoadClubThread();
        l.run();
        clubs=l.getClubs();

        ObservableList<String> list = FXCollections.observableArrayList();

        for (SportskiKlub club : clubs.values()) {
            list.add(club.getNaziv());
        }
        homeClubCombo.setItems(list);
        LoadStadiumThread s=new LoadStadiumThread();
        s.run();
        stadions=s.getStadion();
    }
    @FXML
    public void saveStadium()
    {
        if(nameText.getText()==null|| locationText.getText()==null || capacityText.getText()==null || homeClubCombo.getValue()==null)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Please input the stadium information!");
            alert.show();
        }
        else
        {
            Optional<Long> maxId = stadions.keySet()
                    .stream()
                    .max(Long::compareTo);
            Long id;
            id = maxId.orElse(1L);
            Long clubID=0L;
            for(Long l:clubs.keySet())
            {
                if(clubs.get(l).getNaziv().equals(homeClubCombo.getValue()))
                {
                    clubID=l;
                }
            }
            Stadion s=new Stadion(id,nameText.getText(),locationText.getText(),Long.valueOf(capacityText.getText()),clubID);
            AddStadiumThread addStad=new AddStadiumThread(s);
            addStad.run();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Success!");
            alert.setContentText("Successful input!");
            alert.setHeaderText(null);
            alert.show();
        }
    }
    public void back()
    {
        goBack();
    }
}
