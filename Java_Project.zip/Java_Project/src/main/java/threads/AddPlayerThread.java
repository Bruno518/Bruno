package threads;

import model.entity.Igrac;
import model.entity.SportskiKlub;
import model.enumeration.Aktivnost;
import model.interfaces.ObjectWrite;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import static com.example.java_project.Database.closeConnection;
import static com.example.java_project.Database.makeConnection;

public class AddPlayerThread implements Runnable, ObjectWrite {
    private final Igrac s;
    public AddPlayerThread(Igrac s)
    {
        this.s=s;
    }

    @Override
    public void run() {
        Connection connection = makeConnection();

            try (PreparedStatement preparedStatement = connection.prepareStatement
                    ("INSERT INTO java_projekt.igrac (ime, prezime, broj_igraca, odigrane_utakmice, broj_golova, id_kluba, aktivnost) values (?,?,?,?,?,?,?);", Statement.RETURN_GENERATED_KEYS)) {
                preparedStatement.setString(1, s.getIme());
                preparedStatement.setString(2, s.getPrezime());
                preparedStatement.setLong(3, s.getBrojIgraca());
                preparedStatement.setLong(4, s.getBrojOdigranihUtakmica());
                preparedStatement.setLong(5, s.getBrojGolova());
                preparedStatement.setLong(6, s.getIdKluba());
                preparedStatement.setString(7, Aktivnost.AKTIVAN.getStatus());
                preparedStatement.executeUpdate();
                writeObject(s);
            } catch (SQLException | IOException e) {
                throw new RuntimeException(e);
            } finally {
                closeConnection(connection);
            }
        }
}
