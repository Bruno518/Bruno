package threads;

import model.entity.SportskiKlub;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import static com.example.java_project.Database.closeConnection;
import static com.example.java_project.Database.makeConnection;

public class LoadClubThread implements Runnable{

    private Map<Long, SportskiKlub> clubs;
    @Override
    public void run()
    {
        Map<Long, SportskiKlub> clubs=new HashMap<>();
        Connection connection = makeConnection();

        try (Statement statement = connection.createStatement()) {
            ResultSet set = statement.executeQuery("SELECT * from java_projekt.sportski_klub");

            while (set.next()) {
                clubs.put(set.getLong("id"),new SportskiKlub(set.getLong("id"),set.getString("ime_kluba")));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeConnection(connection);
        }
        this.clubs=clubs;
    }

    public Map<Long, SportskiKlub> getClubs() {
        return clubs;
    }

}
