package threads;

import model.entity.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import static com.example.java_project.Database.closeConnection;
import static com.example.java_project.Database.makeConnection;

public class LoadGameThread implements Runnable{
    private Map<Long, Utakmica> games;
    private Map<Long, SportskiKlub> clubs;
    @Override
    public void run()
    {
        LoadClubThread l=new LoadClubThread();
        l.run();
        clubs=l.getClubs();

        Map<Long, Utakmica> games=new HashMap<>();
        Connection connection = makeConnection();

        try (Statement statement = connection.createStatement())
        {
            ResultSet set = statement.executeQuery("SELECT * from java_projekt.utakmica");
                while (set.next())
                {
                    SportskiKlub s1=clubs.get(set.getLong("id_kluba1"));
                    SportskiKlub s2=clubs.get(set.getLong("id_kluba2"));
                    if(set.getLong("id_natjecanja")==0L)
                    {
                        Utakmica u= new PrijateljskaUtakmica(set.getLong("id"),
                                s1, s2, (set.getDate("dat_utakmice")).toLocalDate(),set.getLong("id_stadion"));
                        u.setRezultatUtakmice(set.getString("rez_utakmice"));
                        games.put(set.getLong("id"),u);
                    }
                    else
                    {
                        Utakmica u= new NatjecateljskaUtakmica(set.getLong("id"),
                                s1, s2, (set.getDate("dat_utakmice")).toLocalDate(),
                                set.getLong("id_natjecanja"),set.getLong("id_stadion"));
                        u.setRezultatUtakmice(set.getString("rez_utakmice"));
                        games.put(set.getLong("id"),u);
                    }
                }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeConnection(connection);
        }
        this.games=games;
    }

    public Map<Long, Utakmica> getGames() {
        return games;
    }
}
